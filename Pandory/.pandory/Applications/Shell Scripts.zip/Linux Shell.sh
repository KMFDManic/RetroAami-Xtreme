export LD_LIBRARY_PATH="/tmp/pandory/lib:/usr/lib:/lib"
/tmp/pandory/bin/yaft < /dev/tty0
