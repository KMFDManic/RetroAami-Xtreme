#!/bin/ash
export LD_LIBRARY_PATH="/tmp/pandory/lib:/usr/lib:/lib"
/tmp/pandory/bin/scummvm \
	--config=/mnt/Pandory/.user/.config/scummvm/scummvm.ini \
;
