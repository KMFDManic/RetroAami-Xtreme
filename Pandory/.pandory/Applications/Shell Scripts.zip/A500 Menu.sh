#!/bin/ash
killall -9 retroarch
killall -9 manhattan
manhattan &
